utils::globalVariables("j")
